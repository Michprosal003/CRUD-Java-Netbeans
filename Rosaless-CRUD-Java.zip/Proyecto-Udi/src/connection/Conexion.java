






package connection;

//***************************************//

import java.sql.Connection;
import java.sql.DriverManager;


//**************************************//

public class Conexion {
    
    
    public Connection Conectar() {
        
        Connection conect=null;
        
        try {
            
            Class.forName("com.mysql.jdbc.Driver");
            
            conect=DriverManager.getConnection("jdbc:mysql://localhost:3306/usma","root","");
            
        }
        
        catch(Exception e)
        {
            
        }
        
        return conect;
        
        
        
    }
    
      
}
